<?php
class M_DetalladoVentas extends ModeloBase
{
    private $table;
    public function __construct($adapter)
    {
        $table = "detalle_ventas";
        parent::__construct($table, $adapter);
    }

    public function getDetalleVentas()
    {
        $query = $this->fluent()->from('detalle_venta DV')
                ->join('venta V ON V.idventa = DV.idventa')
                ->join('personas P ON P.idpersona = V.idCliente')
                ->join('usuarios U ON U.idusuario V.idusuario')
                ->join('empleado E ON E.idempleado = U.idempleado')
                ->join('sucursal S ON S.idsucursal = V.idsucursal')
                ->select('P.nombre AS nombreCLiente, E.nombre AS nombreEmpleado, CONCAT(V.serie_comprobante, v.num_comprobante) AS comprobanteVenta, S.razon_social as nombreSucursal');

        $result = $query->fetchAll();
        return $result;
    }

}