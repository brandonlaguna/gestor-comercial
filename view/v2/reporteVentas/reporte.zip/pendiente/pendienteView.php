<link rel="stylesheet" href="node_modules/tui-grid/dist/tui-grid.min.css">
<div class="br-pagetitle"></div>
<div class="br-pagebody">
<p>Reporte Ventas pendientes</p>
    <div class="br-section-wrapper">
    <div class="table-wrapper">
    <div id="gridReporteVentaPendiente" style="width: 100%;"></div>
    </div>
</div>

