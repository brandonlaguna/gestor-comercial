<script>
    var reporteGeneral = tui.Grid({
        el: document.getElementById('gridReporteVentaPendiente'),
        data: {
        api: {
            readData: { url: 'reporteVentas?action=pendienteAjax', method: 'POST' }
        },
        initialRequest:true,
        },
        scrollX: true,
        scrollY: true,
        minBodyHeight: 50,
            header: {
            height: 50,
        },
        minWidth:60,
        columns: [
        {
            header:'ID',
            name:'id',
            width: 40
        },
        {
            header:'Fecha',
            name:'fecha',
            minWidth: 40
        },
        {
            header:'Sucursal',
            name:'sucursal',
            minWidth: 70
        },
        {
            header:'Empleado',
            name:'empleado',
        },
        {
            header:'Cliente',
            name:'cliente',
        },
        {
            header:'Comprobante',
            name:'comprobante',
        },
        {
            header:'Impuesto',
            name:'impuesto',
        },
        {
            header:'Días',
            name:'dias_credito',
        },
        {
            header:'Pendiente',
            name:'pendiente',
        },
        {
            header:'Estado',
            name:'estado',
        }
    ],
    columnOptions: {
        resizable: true
    },
    summary: {
        height: 40,
        position: 'bottom', // or 'top'
        columnContent: {
            pendiente: {
                template: function(valueMap) {
                    return `${valueMap.sum}`;
                }
            }
        }
    }
    });


</script>

